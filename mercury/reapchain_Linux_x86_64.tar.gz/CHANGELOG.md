1601b51 (HEAD -> main, origin/main, origin/HEAD) change go.mod and add go.sum
deb07e7 change go.sum and add comment to makefile
1ae61e4 Merge branch 'governance_development' into main
7bddaa2 (origin/governance_development) feat: Added keyword changes and SDK v.0.3 update
d121dd2 Merge branch 'master' into main
3dc89e5 Merge branch 'main'
8e8f245 Initial commit
9e38337 delete .idea because it is not used
5d11ec4 modify for multi-node test. Please change working-dir to your path.
302ba46 replace tendermint -> reapchain
482af04 (tag: gd.v0.0.1) feat: New Mint and Burn features added
b7f4808 Added Dual Governance
1d5ce63 fixed bug in vue.js
3d28a05 (tag: v0.0.1) update go.mode for core and sdk version change
2f45b42 feat: Imported Governance Module from SDK into Reapchain Mainnet, modified app.go to reference local governance module.
7abd06a apply reapchain-core modification
2be95ae update the project source code based on starport v0.15.3 to v0.16.2(reapchain starport v0.0.2)
a8be0e8 Change package github.com/reapchain/reapchain -> github.com/reapchain/reapchain-mainnet & Change module to reapchain
a4cd842 move reap parameter location
61699c1 change module name reapchain to reap
350d308 add Makefile
d84a5d6 change config.yml for changing denom token to reap
f838452 add new antehandler and some types for reapchain
c2dadc7 change module name reapchain to reap
77ef551 Initialized with Starport
